////////////////////////////////////////////////////////////////////////////////
// This is a Javascript script which aim is to raise en event on a $U node
// in response to a Sysload alert
//
// Note that you can inform either your credentials to $U
// or a valid authentication key
////////////////////////////////////////////////////////////////////////////////

var did_login = false;
var log_file_name;
var log_to_file = true;

// Please inform the definition of the target $U node here
var host = "{TARGET_$U_HOST}";	// ex: var host = "localhost"
var port = {TARGET_$U_PORT};	// ex: var port = 10600
var area = "{TARGET_$U_AREA}";	// ex: var area = "X"

// You can give a valid authentication key here
var authentication_key;
// Or you can give your credentials here
var user;
var password;
// But you must inform one or the other
// If you inform both then only the authentication key will be taken into account

// You can modify the default "SYSLOAD" event type here
var event_type = "SYSLOAD";

WScript.Quit(main());


function main () {
	LogHeader();

	if (WScript.arguments.length != 10) {
		Log("Incorrect number of parameters");
		return 1;
	}

	if (authentication_key === undefined) {
		// No authentication key defined => Log in to retrieve one
		if (user === undefined || password === undefined) {
			Log("You should give a valid authentication key or credentials inside this script");
			return 1;
		}
		
		if (loginDUASApi())
			return 1;
		did_login = true;
	}

	// Launch the $U event
	if (triggerEventDUASApi())
		return 1;

	if (did_login) {
		// We got a authentication key by a login => just delete it by a logout
		if (logoutDUASApi())
			return 1;
	}

	return 0;
}


// Manage the login request
function loginDUASApi() {
    var http_request;
    var login_url;
    var response;
    
    // Build the login URL
    login_url = "http://" + host + ":" + port + "/access?user=" + user + "&pwd=" + password
    
    // Build the login request object
    http_request = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
	try {
		http_request.Open("GET", login_url, false);
	} catch (err) {
		Log("http://" + host + ":" + port + "/access URL is invalid");
		return 1;
	}
	
    // Send the login request to DUAS
	try {
		http_request.Send();
	} catch (err) {
		Log("Cannot connect to " + host + ":" + port);
		return 1;
	}
    
    // Manage the response
	response = eval('(' + http_request.ResponseText + ')');
	if (response.status == "success") {
		authentication_key = response.data[0].token;
		Log("Login on " + host + ":" + port + " -> Success");
		return 0;
    } else if (response.status == "fail") {
		Log("Login on " + host + ":" + port + " -> Failed [" + response.error.code + "]: " + response.error.message);
		return 1;
	}
}


// Manage the event request
function triggerEventDUASApi() {
    var http_request;
    var event_url;
    var body_data;
        
    // Build the login URL
    event_url = "http://" + host + ":" + port + "/event";
    
    // Build the "event" request object
    http_request = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
	try {
		http_request.Open("POST", event_url, false);
	} catch (err) {
		Log("http://" + host + ":" + port + "/event URL is invalid");
		return 1;
	}

	// Add the headers
    http_request.setRequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
    http_request.setRequestHeader("Content-type", "text/plain");
    http_request.setRequestHeader("Authorization", authentication_key);
	
	// Add basic definition
	body_data = "type=" + event_type + "\n";
	body_data += "area=" + area + "\n";
    
	// Add the Sysload parameters
	body_data += "AGENT_TYPE=" + WScript.arguments(0) + "\n";
	body_data += "AGENT_IP=" + WScript.arguments(1) + "\n";
	body_data += "AGENT_INSTANCE=" + WScript.arguments(2) + "\n";
	body_data += "ALERT_NAME=" + WScript.arguments(3) + "\n";
	body_data += "ALERT_INSTANCE=" + WScript.arguments(4) + "\n";
	body_data += "ALERT_PRIORITY=" + WScript.arguments(5) + "\n";
	body_data += "ALERT_STATE=" + WScript.arguments(6) + "\n";
	body_data += "ALERT_DATE=" + WScript.arguments(7) + "\n";
	body_data += "ALERT_DURATION=" + WScript.arguments(8) + "\n";
	body_data += "ALERT_MESSAGE=" + WScript.arguments(9) + "\n";
    
	// Send the event request to DUAS
	try {
		http_request.Send(body_data);
	} catch (err) {
		Log("Cannot connect to " + host + ":" + port);
		return 1;
	}
	
	// Manage the response
	return manageDUASResponse(http_request.ResponseText);
}


// Manage the response to the event request
function manageDUASResponse(response) {
    var parsed_response;
    var iter;

    // Parse the response
	parsed_response = eval('(' + response + ')');
    
	// Read the status of the response
	if (parsed_response.status == "fail") {
		Log("Launch the " + event_type + " event -> Fail [" + parsed_response.error.code + "]: " + parsed_response.error.message);
		return 0;
	}
	
	if (parsed_response.status == "success")
		Log("Launch the " + event_type + " event -> Success");
	else if (parsed_response.status == "incomplete")
		Log("Launch the " + event_type + " event -> Incomplete");
	
	// Read the data of the response
    if (!(parsed_response.data === undefined)) {     
        for (iter = 0; iter < parsed_response.data.length; iter++) {
			var data = parsed_response.data[iter];
            var triggerName = data.trigger;
         
            if (!(data.error === undefined))
				Log("   => Trigger: " + triggerName + " -> Error [" + data.error.code + "]: " + data.error.message);
            else
				Log("   => Trigger: " + triggerName + " -> Launch number: " + data.launch_number);
		}
    } else {
		Log("   -> No corresponding trigger");
	}

	return 0;
}


// Manage the logout request
function logoutDUASApi() {
    var http_request;
    var logout_url;
    var response;
    
    // Build the logout URL
    logout_url = "http://" + host + ":" + port + "/access?token=" + authentication_key;
    
    // Build the logout request object
    http_request = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
	try {
		http_request.Open("DELETE", logout_url, false);
	} catch (err) {
		Log("http://" + host + ":" + port + "/access URL is invalid");
		return 1;
	}
    
    // Send the logout request to DUAS
	try {
		http_request.Send();
	} catch (err) {
		Log("Cannot connect to " + host + ":" + port);
		return 1;
	}

    // Manage the response
	response = eval('(' + http_request.ResponseText + ')');
    if (response.status == "success") {
		Log("Logout -> Success");
		return 0;
    } else if (response.status == "fail") {
		Log("Logout -> Fail [" + response.error.code + "]: " + response.error.message);
		return 1;
	}
}


// Logging functions
function LogHeader () {
	var currentdate = new Date();
    var month = currentdate.getMonth() + 1;
    var day = currentdate.getDate();
    var date_string = currentdate.getFullYear() + "/" + (("" + month).length < 2 ? "0" : "") + month + "/" + (("" + day).length < 2 ? "0" : "") + day;
	Log("");
	Log("Script launched the " + date_string + " at " + currentdate.getHours() + ":" + currentdate.getMinutes() + ":" + currentdate.getSeconds());
}

function Log(line) {
	if (log_to_file) {
		// Log to file
		if (log_file_name === undefined) {
			// Retrieve the path to the log file
			log_file_name = WScript.ScriptFullName.replace(".js", ".log");
		}

		// Log the specified line
		var file_system =  new ActiveXObject("Scripting.FileSystemObject");
		var log_file = file_system.OpenTextFile(log_file_name, 8, true);
		log_file.WriteLine(line + "\n");
		log_file.Close();
	} else {
		// Console output
		WScript.Echo(line);
	}
}
